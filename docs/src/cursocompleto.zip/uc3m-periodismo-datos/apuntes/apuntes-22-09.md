# Clase **22-09**

Concepto de fin de línea, distinto según el sistema operativo. El problema EOL =  END OF LINE. Mac y Linux comparten muchas cosas pq evulucionan de las viejas máquinas UNIX. La primera línea es la de cabecera. 

## Tipos de datos numéricos
- Integer = números enteros, sin decimales 
- Decimal = números con decimales pero cin pocos decimales y siempre el mismo números de decimales. Son más lentos de procesar que los **float**
- Float o Double = números con decimales pero que pueden tener muchos decimales y/o variables en su longitud. 
- Date o Datetime = la forma más estándar suele ser la que sigue el esquema (YYYY-MM-DD), año, mes y día. Se utiliza guion para separar. A veces incluye también la hora = **time** a continuación de la fecha, o bien separada con una (T), o simplemente con otro guion
- Period = tipo de dato de tiempo periódico que obedece al periodod de la muestra del dato. (P al inicio indica que se trata de un dato periódico)

## Vídeo Y2K problem solved on CFCN TV (1998) 
Solucionar el problema de los PCs que no reconocían el año 2000, sino que volvían al 1900. Desde el 1998, el equipo de Bill Clinton se ocupa de ellos para que no haya una "hecatombe"

## Tipos de datos 
- Strings = cadena de caracteres o literales al texto normal 
- Booleanos = representan dos valores de una lógica binaria (Verdadero o Falso), (Sí o No), (0 o 1), etc. Su nombre se debe a ------

## Terminal 
Para copiar en la terminal apretar botón Mayus + Insert 
- Entrada típica 
- Salida típica 
- Entrada de errores 
