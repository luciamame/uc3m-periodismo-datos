# Clase **05-10**

## Terminal 
Mostrar las variables en la terminal 
- ls &rarr; sirve para listar archivos del directorio donde estemos.LS ES UN COMANDO Y LO QUE VIENE DETRÁS SON LAS OPCIONES Y LOS ARGUMENTOS
- ls -l &rarr; listar de forma completa los archivos (información: permisos, propiedad, tamaño, fecha de modificación)
- ls -a &rarr; mostrar los archivos ocultos. bash_history = lo que has hecho en la terminal y bash_profile = archivo dónde están las carácterísticas que vas a usar en la terminal
- env &rarr;listar variables de entorno 
- pwd &rarr; para saber dónde estás 
- cat &rarr; se utiliza para con**cat**enar
- mkdir &rarr; crear una carpeta. Cuando se pone en plural argumentos, significa que puedo crear 5 directorios a la vez
- cd &rarr; meterte en una carpeta. El nombre es en realidad la ruta relativa. La absoluta sería cd/home/USUARIO/borrar/
- man &rarr; de manual, paginador 
- cat --help &rarr; pedir ayuda de manera sintetizada 
- echo &rarr; mostrar las cosas en pantalla + crear archivo de texto. Si ya existe pisa el archivo 
- (>) &rarr; operador para mandar el contenido a un archivo  
- (>>) &rarr; 
- ("") para que la terminal te ponga los datos tal cual. Si está entre comillas lo entiende como un todo 
- asterísco &rarr; todos los archivos que tienes hasta el momento los pone todos juntos (sin necesidad de escribirlos) en un nuevo archivo
- file &rarr;
- du -sh &rarr;
- wc -l &rarr; número de líneas del archivo 
- head &rarr; cabecera, primeros datos. head -x (x= númeor de líneas que quieres ver)   
- tail &rarr; últimos datos 
