# Clase **06-10**

## Introduccióm al periodismo de datos 
Volvemos al ppt que ya habíamos visto sobre los inicios del periodismo de datos/de precisión 
