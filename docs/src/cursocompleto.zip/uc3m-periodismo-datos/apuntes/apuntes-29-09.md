# Clase **29-09**

## API BASH 
- STDIN 
- STDOUT
- STDERR
## TERMINAL 
- less &rarr; para paginar 
- cat &rarr; visor de lo que has descargado
- **>** &rarr; le dices que en vez de pantalla la manda a un archivo 
- q &rarr; salir
- | &rarr; comando pasa como entrada de datos al comando siguiente que es less (paginador), es como pasar de una acción a otea de manera concatenada
