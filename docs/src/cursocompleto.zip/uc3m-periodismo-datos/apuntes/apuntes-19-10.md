# Clase *19-10*

## Google Dorks 
Herramientas en línea de comando 
- site
- filetype:xls / pdf (se refiere al formato del documento)
