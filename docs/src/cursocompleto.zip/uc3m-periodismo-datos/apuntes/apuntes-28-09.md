# Clase **28-09**

## Terminal
- date &rarr; Saber la fecha y la hora
- borrar &rarr; ctrl+l 
- pegar &rarr; Insert + Mayús
- volver a escribir algo, sin escribirlo &rarr; cursor hacia arriba (flecha) 
- cd &rarr; meterte en otra caprte, pero le tienes que decir en cual 
- para que escriba solo, tenemos que empezar a escribir la palabra y le datos dos veces al tabulador
- git remote -v &rarr; 
- cd .. &rarr; sirvbe para ir hacia atrás o hacia arriba es decir salir de donde estés

## Sincronizar la terminal con github 
Tenemos que descargarnos **git** en el terminal pq de momento nuestras cosas no nos pertenecen sino que están en la nube, son de Microsoft
**Git** está entre GH (Github) y nuestro ordenador 
Desde el ordenador le decimos git clone URL nombe, porque ya tenemos un repositorio en Github.
Ahora vamos a clonar en nuestros ordenadores su repositorio de Github y luego los nuestros

## The Guardian 
La dirección es lo primero de la estructura de ficheros. Por encima de esto está el parent y por debajo child. 
En el caso del The Guardian después del punto cero tenemos: *(us-news/2021/sep/27/x noticia)*
Ruta relativa, son relativas al lugar del árbol del directorio en el que me encuentro. Es decir y el mismo día publico más de una noticia puedo poner  que "noticia 2" a *href =* "noticia"
También existen rutas absolutas, donde para la *noticia 2* hacemos un directorio nuevo completo. Se emplea el *https://*
Cuando no pone *http* o *https://* es para que se puede abrir la una o la otra, se deja sin determinar. 

## pwd en la terminal 
PWD: Print Working Directory &rarr; sirve para saber tu nombre de usuario en el PC 

## bootstrap 
Interfaz de Twitter que luego se liberalizó y por tanto la tienen muchas páginas webs, entre ellas Github. 
