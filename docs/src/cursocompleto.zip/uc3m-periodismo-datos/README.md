# Periodimo de Datos UC3M

Notas sobre **periodismo de datos** en *UC3M*

## Qué es el periodismo de datos
- Periodismo
- Visualización
- Datos

## HTTP
Es una _API_ que tiene cuatro tareas posibles:
1. Post 
2. Get 
3. Delete 
4. Put 
